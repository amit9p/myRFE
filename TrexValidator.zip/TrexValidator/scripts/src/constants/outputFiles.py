

#East West Matching Validation Report Location:

D1 = 'file:///home/amitprasad/MyFolder/TrexValidator/matching_output/D1'
D2A = 'file:///home/amitprasad/MyFolder/TrexValidator/matching_output/D2A'
D2B = 'file:///home/amitprasad/MyFolder/TrexValidator/matching_output/D2B'


#East West Non Matching Validation Report


D1_ = 'file:///home/amitprasad/MyFolder/TrexValidator/non_matching_output/D1'
D2A_ = 'file:///home/amitprasad/MyFolder/TrexValidator/non_matching_output/D2A'
D2B_ = 'file:///home/amitprasad/MyFolder/TrexValidator/non_matching_output/D2B'
