
# Sqls To Fetch Matching Records Between East And West Region

d1_byteCount_sql = ''' select D1_East_Tbl_Nm as TblNm , D1_East_Byte_Count , D1_West_Byte_Count from D1BYTE_EAST , D1BYTE_WEST where D1BYTE_EAST.D1_East_Byte_Count = D1BYTE_WEST. D1_West_Byte_Count'''
d1_rowCount_sql = ''' select D1_East_Tbl_Nm as TblNm , D1_East_Row_Count , D1_West_Row_Count from D1COUNT_EAST , D1COUNT_WEST where  D1COUNT_EAST.D1_East_Row_Count = D1COUNT_WEST.D1_West_Row_Count'''
d1_ddl_sql = ''' select D1_East_Tbl_Nm as TblNm , D1_East_Ddl_Count , D1_West_Ddl_Count from D1DDL_EAST , D1DDL_WEST where  D1DDL_EAST.D1_East_Ddl_Count = D1DDL_WEST.D1_West_Ddl_Count'''
d1_hashCount_sql = ''' select D1_East_Tbl_Nm as TblNm ,D1_East_Hash_Count , D1_West_Hash_Count from D1HASH_EAST , D1HASH_WEST where  D1HASH_EAST.D1_East_Hash_Count = D1HASH_WEST.D1_West_Hash_Count'''
d1_udfCount_sql = ''' select D1_East_Tbl_Nm as TblNm ,D1_East_Udf_Count , D1_West_Udf_Count from D1UDF_EAST , D1UDF_WEST where D1UDF_EAST.D1_East_Udf_Count = D1UDF_WEST.D1_West_Udf_Count'''



d2a_byteCount_sql = ''' select D2A_East_Tbl_Nm as Tbl_Nm, D2A_East_Byte_Count , D2A_West_Byte_Count from D2ABYTE_EAST , D2ABYTE_WEST where  D2ABYTE_EAST.D2A_East_Byte_Count =  D2ABYTE_WEST.D2A_West_Byte_Count'''
d2a_rowCount_sql = '''select D2A_East_Tbl_Nm as Tbl_Nm,D2A_East_Row_Count , D2A_West_Row_Count from D2ACOUNT_EAST , D2ACOUNT_WEST where D2ACOUNT_EAST. D2A_East_Row_Count = D2ACOUNT_WEST.D2A_West_Row_Count'''
d2a_ddl_sql = '''select D2A_East_Tbl_Nm as Tbl_Nm,D2A_East_Ddl_Count ,D2A_West_Ddl_Count from D2ADDL_EAST , D2ADDL_WEST where D2ADDL_EAST.D2A_East_Ddl_Count = D2ADDL_WEST.D2A_West_Ddl_Count '''
d2a_hashCount_sql = '''select D2A_East_Tbl_Nm as Tbl_Nm,D2A_East_Hash_Count , D2A_West_Hash_Count from D2AHASH_EAST , D2AHASH_WEST where  D2AHASH_EAST.D2A_East_Hash_Count = D2AHASH_WEST.D2A_West_Hash_Count'''
d2a_udfCount_sql = '''select D2A_East_Tbl_Nm as Tbl_Nm,D2A_East_Udf_Count , D2A_West_Udf_Count from D2AUDF_EAST , D2AUDF_WEST where D2AUDF_EAST.D2A_East_Udf_Count = D2AUDF_WEST.D2A_West_Udf_Count '''




d2b_byteCount_sql = ''' select D2B_East_Tbl_Nm as Tbl_Nm ,D2B_East_Byte_Count ,D2B_West_Byte_Count from D2BBYTE_EAST , D2BBYTE_WEST where D2BBYTE_EAST. D2B_East_Byte_Count = D2BBYTE_WEST.D2B_West_Byte_Count'''
d2b_rowCount_sql = ''' select D2B_East_Tbl_Nm as Tbl_Nm ,D2B_East_Row_Count ,D2B_West_Row_Count from D2BCOUNT_EAST ,D2BCOUNT_WEST where D2BCOUNT_EAST.D2B_East_Row_Count = D2BCOUNT_WEST.D2B_West_Row_Count'''
d2b_ddl_sql = ''' select D2B_East_Tbl_Nm as Tbl_Nm ,D2B_East_Ddl_Count , D2B_West_Ddl_Count from D2BDDL_EAST ,D2BDDL_WEST where D2BDDL_EAST.D2B_East_Ddl_Count = D2BDDL_WEST.D2B_West_Ddl_Count'''
d2b_hashCount_sql = '''select D2B_East_Tbl_Nm as Tbl_Nm ,D2B_East_Hash_Count , D2B_West_Hash_Count from D2BHASH_EAST ,D2BHASH_WEST  where  D2BHASH_EAST.D2B_East_Hash_Count = D2BHASH_WEST.D2B_West_Hash_Count'''
d2b_udfCount_sql = '''select D2B_East_Tbl_Nm as Tbl_Nm ,D2B_East_Udf_Count ,D2B_West_Udf_Count from D2BUDF_EAST , D2BUDF_WEST where D2BUDF_EAST.D2B_East_Udf_Count =  D2BUDF_WEST.D2B_West_Udf_Count'''



# Sqls To Fetch Non Matching Records Between East And West Region

d1_byteCount_sql_ = '''SELECT D1_East_Tbl_Nm as TblNm ,  t1.ID FROM Table1 t1 LEFT JOIN Table2 t2 ON t1.ID = t2.ID WHERE t2.ID IS NULL '''
d1_rowCount_sql_ = ''' SELECT D1_East_Tbl_Nm as TblNm ,   t1.ID FROM Table1 t1 LEFT JOIN Table2 t2 ON t1.ID = t2.ID WHERE t2.ID IS NULL'''
d1_ddl_sql_ = ''' SELECT D1_East_Tbl_Nm as TblNm ,  t1.ID FROM Table1 t1 LEFT JOIN Table2 t2 ON t1.ID = t2.ID WHERE t2.ID IS NULL'''
d1_hashCount_sql_ = '''SELECT D1_East_Tbl_Nm as TblNm ,  t1.ID FROM Table1 t1 LEFT JOIN Table2 t2 ON t1.ID = t2.ID WHERE t2.ID IS NULL '''
d1_udfCount_sql_ = '''SELECT D1_East_Tbl_Nm as TblNm ,  t1.ID FROM Table1 t1 LEFT JOIN Table2 t2 ON t1.ID = t2.ID WHERE t2.ID IS NULL '''



d2a_byteCount_sql_ = '''SELECT D2A_East_Tbl_Nm as Tbl_Nm, t1.ID FROM Table1 t1 LEFT JOIN Table2 t2 ON t1.ID = t2.ID WHERE t2.ID IS NULL '''
d2a_rowCount_sql_ = '''SELECT D2A_East_Tbl_Nm as Tbl_Nm, t1.ID FROM Table1 t1 LEFT JOIN Table2 t2 ON t1.ID = t2.ID WHERE t2.ID IS NULL '''
d2a_ddl_sql_ = ''' SELECT D2A_East_Tbl_Nm as Tbl_Nm, t1.ID FROM Table1 t1 LEFT JOIN Table2 t2 ON t1.ID = t2.ID WHERE t2.ID IS NULL'''
d2a_hashCount_sql_ = '''SELECT D2A_East_Tbl_Nm as Tbl_Nm, t1.ID FROM Table1 t1 LEFT JOIN Table2 t2 ON t1.ID = t2.ID WHERE t2.ID IS NULL '''
d2a_udfCount_sql_ = '''SELECT D2A_East_Tbl_Nm as Tbl_Nm, t1.ID FROM Table1 t1 LEFT JOIN Table2 t2 ON t1.ID = t2.ID WHERE t2.ID IS NULL '''




d2b_byteCount_sql_ = '''SELECT D2B_East_Tbl_Nm as Tbl_Nm , t1.ID FROM Table1 t1 LEFT JOIN Table2 t2 ON t1.ID = t2.ID WHERE t2.ID IS NULL '''
d2b_rowCount_sql_ = '''SELECT D2B_East_Tbl_Nm as Tbl_Nm , t1.ID FROM Table1 t1 LEFT JOIN Table2 t2 ON t1.ID = t2.ID WHERE t2.ID IS NULL '''
d2b_ddl_sql_ = '''SELECT D2B_East_Tbl_Nm as Tbl_Nm , t1.ID FROM Table1 t1 LEFT JOIN Table2 t2 ON t1.ID = t2.ID WHERE t2.ID IS NULL '''
d2b_hashCount_sql_ ='''SELECT D2B_East_Tbl_Nm as Tbl_Nm , t1.ID FROM Table1 t1 LEFT JOIN Table2 t2 ON t1.ID = t2.ID WHERE t2.ID IS NULL '''
d2b_udfCount_sql_ = '''SELECT D2B_East_Tbl_Nm as Tbl_Nm , t1.ID FROM Table1 t1 LEFT JOIN Table2 t2 ON t1.ID = t2.ID WHERE t2.ID IS NULL '''


test_sql = ''' select D1_East_Byte_Count from D1BYTE_EAST left join D1BYTE_WEST on  D1BYTE_EAST.D1_East_Byte_Count = D1BYTE_WEST.D1_West_Byte_Count where D1BYTE_WEST.D1_West_Byte_Count is null '''
test_sql2 = ''' (select D1_East_Byte_Count from D1BYTE_EAST t1 EXCEPT Select D1_West_Byte_Count from D1BYTE_WEST t2) UNION (select D1_West_Byte_Count from D1BYTE_WEST t2 EXCEPT Select D1_East_Byte_Count from D1BYTE_EAST t1)'''
test_sql3 = '''SELECT D1_East_Tbl_Nm as TblNm,D1BYTE_EAST.D1_East_Byte_Count FROM D1BYTE_EAST  LEFT JOIN D1BYTE_WEST  ON D1BYTE_EAST.D1_East_Byte_Count = D1BYTE_WEST.D1_West_Byte_Count WHERE D1BYTE_WEST.D1_West_Byte_Count IS NULL '''





