from pyspark.sql import SparkSession
from pyspark import SparkContext
from pyspark import SparkConf
from pyspark.sql import SQLContext


class SparkUtil:
  def __init__(self, name):
    self.name = name


  def getSparkSession(self):
    print("Hello my name is " + self.name)
    spark = SparkSession\
                .builder\
                .master('local')\
                .appName(self.name)\
                .config("spark.sql.crossJoin.enabled","true")\
                .getOrCreate()
    return spark


